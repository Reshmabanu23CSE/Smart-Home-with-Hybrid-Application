// Initialize Firebase
//The project has been deleted in firebase
//fill in your own config info 
// Initialize Firebase
  var config = {
    apiKey: "AIzaSyBBGHNG8fAlo0154b7ba48shrocYY8CkVg",
    authDomain: "hybrid-f44cc.firebaseapp.com",
    databaseURL: "https://hybrid-f44cc.firebaseio.com",
    projectId: "hybrid-f44cc",
    storageBucket: "hybrid-f44cc.appspot.com",
    messagingSenderId: "262891529370"
  };
  firebase.initializeApp(config);

$(document).ready(function(){
  var database = firebase.database();
  var ledStatus;

  database.ref().on("value", function(snap){
    ledStatus = snap.val().ledStatus;
    if(ledStatus == 1){
      $(".lightStatus").text("The light is off");
    } else {
      $(".lightStatus").text("The light is on");
    }
  });

  $(".lightButton").click(function(){
    var firebaseRef = firebase.database().ref().child("ledStatus");

    if(ledStatus == 1){
      firebaseRef.set(0);
      ledStatus = 0;
    } 
	
  });
  $(".lightButton1").click(function(){
    var firebaseRef = firebase.database().ref().child("ledStatus");

    if(ledStatus == 0){
      firebaseRef.set(1);
      ledStatus = 1;
    } 
  
  });

});

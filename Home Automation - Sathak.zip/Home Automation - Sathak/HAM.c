#include "LPC8xx.h"                     // Device header
#include "uart.h"
#include "keypad.h"
#include "sensor_act.h"
#include "gsm.h"
#include "rand.h"
#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "string.h"

char key_data;
int 	event=0;
char cld_data=0;

void GPIO_init()
{
	LPC_SYSCON ->SYSAHBCLKCTRL |= (1<<6);
	LPC_GPIO_PORT ->DIR0 |= (1<<16)|(0<<14)|(0<<13)|(1<<7);
}


void UART1_IRQHandler ()
{
	if (LPC_USART1->STAT & (1<<2))
		{
		while(~LPC_USART1->STAT & (0x1 << 0)); // rx ready ?????
		cld_data = LPC_USART1->RXDAT;
	send_char(0,cld_data);
			if(cld_data == '#')
		{
			LPC_GPIO_PORT->SET0 |= (1<<16);
		}
	
		if(cld_data == '@')
		{
			LPC_GPIO_PORT->CLR0 |= (1<<16);
		}
		}
	}


int main(void)
{
	NVIC_DisableIRQ(UART1_IRQn);

	GPIO_init();

	uart_initialization();
	UART_Init(0,9600, 4, 0);
	UART_Init(2,115200, 6,1 );
	UART_Init(1,115200, 2,3 );
	send_string(0,"Home Sweet Home \n");

	i2c_init();
	i2C_tx_rx();

	LPC_USART1->INTENSET|=(1<<0);
	NVIC_EnableIRQ(UART1_IRQn);
	
	gsm_init();

	while(1)
	{

	

		key_data = 	keypad_alp();
		
		if(key_data == 'F')
		{
		
			
			inside_home();
		
		}
		if(key_data == 'E')
		{
		
			out();
				key_data = 	keypad_alp();
		//}
			if(key_data == 'C' )
			{
			
				key = 68;
				rand_gen();
				keypad_no();
				cmp();
			
			}
		}
	}
}

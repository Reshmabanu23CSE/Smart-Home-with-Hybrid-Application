#include "LPC8xx.h"                     // Device header
#include "uart.h"
#include "gsm.h"

void inside_home()
{
	send_string(0,"inside \r\n");
	if((LPC_GPIO_PORT->B0[14] == 0) &(LPC_GPIO_PORT->B0[13] == 0))
		{
		
			send_string(0, "Gas Leakage Detected\r\n");
			gsm_init();
//			send_string(2, "AT+CMGS=6380604958\r\n");
			send_string(2, "AT+CMGS=9176171322\r\n");
			delay(5000);
			send_string(2, "Gas Leakage Detected\r\n");
			send_char(2,0x1A);
			delay(5000);
			send_char(0,'d');
			while((LPC_GPIO_PORT->B0[14] == 0) &(LPC_GPIO_PORT->B0[13] == 0));
		}
}

void out()
{
	send_string(0,"outside \r\n");
	if((LPC_GPIO_PORT->B0[14] == 0) &(LPC_GPIO_PORT->B0[13] == 0))
		{
			
			send_string(0, "Gas Leakage Detected\r\n");
			gsm_init();
//			send_string(2, "AT+CMGS=6380604958\r\n");
			send_string(2, "AT+CMGS=9176171322\r\n");
			delay(5000);
			send_string(2, "Gas Leakage Detected\r\n");
			send_char(2,0x1A);
			delay(5000);
			send_char(0,'d');
			//while((LPC_GPIO_PORT->B0[14] == 0) &(LPC_GPIO_PORT->B0[13] == 0));
		}
		
		if((LPC_GPIO_PORT->B0[14] == 1) & (LPC_GPIO_PORT->B0[13] == 1))
		{
			
			send_string(0, "Movement Detected\r\n");
			gsm_init();
//			send_string(2, "AT+CMGS=6380604958\r\n");
			send_string(2, "AT+CMGS=9176171322\r\n");
			delay(5000);
			send_string(2, "Movement Detected\r\n");
			send_char(2,0x1A);
			delay(5000);
			send_char(0,'d');
			while((LPC_GPIO_PORT->B0[14] == 1) & (LPC_GPIO_PORT->B0[13] == 1));
		}
		
		if((LPC_GPIO_PORT->B0[14] == 1) &(LPC_GPIO_PORT->B0[13] == 0))
		{
		
			send_string(0, "Gas Leakage & Movements Detected\r\n");
			gsm_init();
//			send_string(2, "AT+CMGS=6380604958\r\n");
			send_string(2, "AT+CMGS=9176171322\r\n");
			delay(5000);
			send_string(2, "Gas Leakage & Movements Detected\r\n");
			send_char(2,0x1A);
			delay(5000);
			send_char(0,'d');
			while((LPC_GPIO_PORT->B0[14] == 1) &(LPC_GPIO_PORT->B0[13] == 0));
		}
	}

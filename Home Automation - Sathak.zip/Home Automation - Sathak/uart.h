
#define max_baud 115200


void delay(int x);
void uart_initialization(void);
void UART_Init(int port, int baud, int tx, int rx);
void send_char(int port, char tx_data);
void send_string(int port, char* tx_data);
int rx_char(int port);
void send_dec(int port, int data);

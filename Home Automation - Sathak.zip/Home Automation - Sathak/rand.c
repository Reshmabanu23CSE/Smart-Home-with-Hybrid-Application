#include "LPC8xx.h"                     // Device header
#include "uart.h"
#include "stdlib.h"
#include "string.h"
#include "time.h"
//#include "rand.h"

void printRandoms(int lower, int upper,  
                             int count) 
{ 
	int b0,b1,b2,b3;
//	int OTP;
    int i; 
    for (i = 0; i < count; i++) 
	{ 
        int num = (rand() % 
           (upper - lower + 1)) + lower; 
			b3=num/1000;
				b3=b3+48;
				num=num%1000;
				b2=num/100;
				b2=b2+48;
				num=num%100;
				b1=num/10;
				b1=b1+48;
				num=num%10;
				b0=num+48;
		
				
      send_char(0, b3);
			send_char(0, b2);
			send_char(0, b1);
			send_char(0, b0);
			send_char(0, '\n');	
		
			send_string(1, "AT+CMGS=9176171322\r\n");
			send_char(1, b3);
			send_char(1, b2);
			send_char(1, b1);
			send_char(1, b0);
				send_char(1,0x1A);
				 send_char(0, 'e');
				 delay(2000);
				 
		//	send_char(0, '\n');				

	//		OTP = ((b3*1000)+(b2*100)+(b1*10)+(b0));	

		//		send_char(0, '\n');		
    } 
} 


void i2c_init(void);
void i2C_tx_rx(void);
void i2c_write(char slave_add, char data, char data2);
int i2c_read(char slave_add);

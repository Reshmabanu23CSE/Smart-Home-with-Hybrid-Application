#include "LPC8xx.h"  		// Device header
#include "uart.h"
#include "string.h"
#include "math.h"
#include "stdio.h"
#include "stdlib.h"
#include "sensor_act.h"
#include "gsm.h"

int rx_data, rx_data1;
// char data, data_x;
int k;
char a=0;
int data,data1;
unsigned char key,key_no;
char key_p[4]; 
//int o;
int r_no;
char r_ar[5];

void delay_key(int x)
{
	int i,j;
	for(i=0;i<x;i++)
	for(j=0; j<x;j++);
}



void i2c_init()
{	
	LPC_SYSCON->SYSAHBCLKCTRL |= (1<<5)|(1<<7)|(1<<18);  //CLOCK FOR SWM & IO CON
	
	LPC_SYSCON->PRESETCTRL |= (0<<6);  				//RESET
	LPC_SYSCON->PRESETCTRL |= (1<<6);					//CLEAR & MAKE I2C READY FOR OPERATION
	
	LPC_SWM->PINASSIGN7 = 11<<24;					//SDA P0_11
	LPC_SWM->PINASSIGN8 = 10<<0;					//SCL P0_10
	
	LPC_IOCON->PIO0_10 |= (1<<9);							//FAST PLUS MODE
	LPC_IOCON->PIO0_11 |= (1<<9);							//FAST PLUS MODE

}

void i2C_tx_rx()
{
 	LPC_I2C0->CLKDIV =2;
//	LPC_I2C0->MSTTIME |= (0X04<<0) | (0X03<<4);
	LPC_I2C0->CFG |= (1<<0);										//ENABLE MASTER


}

void i2c_write(int slave_add, int data, int data2)
{
//	//LPC_I2C0 ->MSTDAT |=0x00;
	LPC_I2C0 ->MSTDAT = slave_add ;				// Write slave address to MSTDAT
//	delay(10);
	LPC_I2C0 ->MSTCTL =(1<<1);						//Start the transmission by setting the MSTSTART bit to 1 in the Master control register.
	while(!(LPC_I2C0 ->STAT & (1<<0)) );		// Wait for the pending status to be set
	
	LPC_I2C0 ->MSTDAT = data; 						// Write 8 bits of data to the MSTDAT register
//	delay(10);
	LPC_I2C0 ->MSTCTL =	(1<<0);						// Continue with the transmission
	while(!(LPC_I2C0 ->STAT & 	(1<<0) ));		// Wait for the pending status to be set
//	
	LPC_I2C0 ->MSTDAT = data2; 						// Write 8 bits of data to the MSTDAT register
//	delay(10);
	LPC_I2C0 ->MSTCTL =(1<<0);						// Continue with the transmission
	while(!(LPC_I2C0 ->STAT & (1<<0) ));		// Wait for the pending status to be set
////	
	LPC_I2C0 ->MSTCTL = (1<<2);						//Stop the transmission
//	delay(20);
	
}



void i2c_read(char slave_add)
{
//	//	LPC_I2C0 ->MSTDAT |=0xFF;
	LPC_I2C0 ->MSTDAT = slave_add ;				// Write slave address to MSTDAT
	LPC_I2C0 ->MSTCTL = 0x2;	//(1<<1);						//Start the transmission by setting the MSTSTART bit to 1 in the Master control register.
	while(!(LPC_I2C0 ->STAT & 	0x1));	//(1<<0)) );		// Wait for the pending status to be set
////	
	rx_data = LPC_I2C0 ->MSTDAT;
//	o++;
		LPC_I2C0 ->MSTCTL =	0x1;	//(1<<0);						// Continue with the transmission
	while(!(LPC_I2C0 ->STAT & 	0x1));	//(1<<0)) );		// Wait for the pending status to be set
//	
	//rx_data1 = LPC_I2C0 ->MSTDAT;
	LPC_I2C0 ->MSTCTL =		0x1;	//(1<<0);						// Continue with the transmission
	while(!(LPC_I2C0 ->STAT & 0x1));//(1<<0)) );		// Wait for the pending status to be set

	LPC_I2C0 ->MSTCTL = 0x4; //(1<<2);						//Stop the transmission

}




char keypad_no()
{
	int count =0;
	while(count <4)
	{
	i2c_write(0x40, 0x7F, 0xFF);
	delay_key(20);
	 i2c_read(0x41);
	delay_key(20);

	if(rx_data == 0x77){
		rx_data=0;
		key_p[count] = '0';
		key_no = '0';
//		send_char(0,key);
			count++;
		delay_key(1000);
	}
			 
		if(rx_data ==0x7B){
			rx_data=0;
			key_no = '4';
			key_p[count] = '4';
//			send_char(0,key);
				count++;
			delay_key(1000);
		}
			
			if(rx_data == 0x7D){
				rx_data=0;
				key_no = '8';
				key_p[count] = '8';
//				send_char(0,key);
					count++;
				delay_key(1000);
		}
			 
		
	i2c_write(0x40, 0xBF, 0xFF);
	delay_key(20);
	i2c_read(0x41);
	delay_key(20);

	if(rx_data == 0xB7){
		rx_data=0;
		key_no = '1';
		key_p[count] = '1';
	//	send_char(0,key);
			count++;
	  delay_key(1000);
	}
			 
	if(rx_data ==0xBB){
		rx_data=0;
		key_no = '5';
//		send_char(0,key);
		key_p[count] = '5';
			count++;
  	 delay_key(1000);
	}
			
	if(rx_data == 0xBD){
		rx_data=0;
		key_no = '9';
//		send_char(0,key);
		key_p[count] = '9';
			count++;
		delay_key(1000);
	}
			 
	 
			 
	i2c_write(0x40, 0xDF, 0xFF);
	delay_key(20);
	i2c_read(0x41);
	delay_key(20);

	if(rx_data == 0xD7){
		rx_data=0;
		key_no = '2';
		key_p[count] = '2';
//		send_char(0,key);
			count++;
		delay_key(1000);
	}
			 
	if(rx_data ==0xDB){
		rx_data=0;
		key_no = '6';
		key_p[count] = '6';
//		send_char(0,key);
			count++;
		delay_key(1000);
	}
			
	
	
	i2c_write(0x40, 0xEF, 0xFF);
	delay_key(20);
	i2c_read(0x41);
	delay_key(20);

	if(rx_data == 0xE7){
		rx_data=0;
		key_no = '3';
		key_p[count] = '3';
//		send_char(0,key);
			count++;
		delay_key(1000);
	}
			 
	if(rx_data ==0xEB){
		rx_data=0;
		key_no = '7';
		key_p[count] = '7';
//		send_char(0,key);
			count++;
		delay_key(1000);
	}
			
	rx_data = '\0';
	}
	if(count == '4')
	{
		 key_p[count] = 0x0A;
	}
	send_string(0,key_p);
	key_p[count] = '\0';
	return key;
}

char keypad_alp()
{
	i2c_write(0x40, 0x7F, 0xFF);
	delay_key(20);
	i2c_read(0x41);
	delay_key(20);


	if(rx_data == 0x7E){
		rx_data=0;
		key = 'C';
		delay_key(1000);
		
		}
	
	i2c_write(0x40, 0xBF, 0xFF);
	delay_key(20);
	i2c_read(0x41);
	delay_key(20);

	if(rx_data == 0xBE){
		rx_data=0;
		key = 'D';
		delay_key(1000);
	}
			 
			 
	i2c_write(0x40, 0xDF, 0xFF);
	delay_key(20);
	i2c_read(0x41);
	delay_key(20);

			
	if(rx_data == 0xDD){
		rx_data=0;
		key = 'A';
		delay_key(1000);
	}
			 
	if(rx_data == 0xDE){
		//rx_data=0;
		 key = 'E';
		 delay_key(1000);
		}
	
	i2c_write(0x40, 0xEF, 0xFF);
	delay_key(20);
	i2c_read(0x41);
	delay_key(20);

	
	if(rx_data == 0xED){
		rx_data=0;
		key = 'B';
		delay_key(1000);
	}
			 
	if(rx_data == 0xEE){
		 key = 'F';
		 delay_key(1000);
	}

	rx_data = '\0';
	return key;
}

void rand_gen()
{
	r_no=rand() % 9000;
      
      if(r_no<=1000)
      {
         r_no=rand() % 9000;
      }
      else
      {
        sprintf(r_ar,"%d",r_no);
			}
			send_string(0,r_ar);
			gsm_init();
//			send_string(2, "AT+CMGS=6380604958\r\n");
			send_string(2, "AT+CMGS=9176171322\r\n");
			delay(5000);
			send_string(2,r_ar);
			send_char(2,0x1A);
			delay(5000);
			send_char(0,'d');
			
}
			
void cmp()
{
	if(strcmp(key_p,r_ar)==0)
	{
		
		send_string(0,"Password Matched... Door Opening...\r\n");
		LPC_GPIO_PORT->SET0 |= (1<<7);
		inside_home();
		//send_string(0,"inside \r\n");
	}
	else
	{
		send_string(0,"Wrong Password\r\n");
		LPC_GPIO_PORT->CLR0 |= (1<<7);
		out();
	}
}


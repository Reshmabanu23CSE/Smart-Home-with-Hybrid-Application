#include "uart.h"

void gsm_init()
{
	send_string(2, "AT\r\n");
	delay(3000);
	send_char(0,'a');
		
//	send_string(0, "AT+CGREG?\r\n");
//	delay(1000000);
//		
//	send_string(0, "AT+CSQ\r\n");
//	delay(1000000);
			
	send_string(2, "AT+CMGF=1\r\n");
	delay(3000);
	send_char(0,'b');	
}

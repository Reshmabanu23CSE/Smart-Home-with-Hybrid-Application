
extern 	int b0,b1,b2,b3;
void printRandoms(int lower, int upper, int count) ;


void gsm_init(void);

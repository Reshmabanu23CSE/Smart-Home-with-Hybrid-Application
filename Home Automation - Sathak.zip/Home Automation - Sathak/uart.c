#include "LPC8xx.h"                     // Device header
#include "uart.h"


void delay(int x)
{
	int i,j;
	for(i=0;	i<x ; i++)
	for(j=0;	j<x ; j++);
}

 void uart_initialization(void)
 {
		LPC_SYSCON->UARTCLKDIV =  32;                   // uart divion 32 imes and bringin to 1.875mhz 
		LPC_SYSCON->UARTFRGDIV = 0xFF;									// Div =255
		LPC_SYSCON->UARTFRGMULT = 4;										// Mul = 4
	 	LPC_SYSCON->PRESETCTRL |= (0<<2);		 					// frg preset						
		LPC_SYSCON->PRESETCTRL |= (1<<2);
		
 }
 
void UART_Init(int port, int baud, int tx, int rx){
	switch(port)
	{
		case 0:
			
			LPC_SYSCON ->SYSAHBCLKCTRL |= (1<<14);
			LPC_SYSCON ->PRESETCTRL |= (0<<3);
			LPC_SYSCON ->PRESETCTRL |= (1<<3);
			LPC_SWM ->PINASSIGN0 = (tx<<0) | (rx << 8);
			LPC_USART0->BRG  = ((max_baud/baud) -1);
			LPC_USART0->CFG |= (1<<2); // 8 bit
			LPC_USART0->CFG |= (1<<0);// uart on
		break;
		
		case 1:
			LPC_SYSCON ->SYSAHBCLKCTRL |= (1<<15);
			LPC_SYSCON ->PRESETCTRL |= (0<<4);
			LPC_SYSCON ->PRESETCTRL |= (1<<4);
			LPC_SWM ->PINASSIGN1 = (tx<<8) | (rx << 16);
			LPC_USART1->BRG  = ((max_baud/baud) -1); 
			LPC_USART1->CFG |= (1<<2); // 8 bit
			LPC_USART1->CFG |= (1<<0);// uart on
		break;

		case 2:
			LPC_SYSCON ->SYSAHBCLKCTRL |= (1<<16);
			LPC_SYSCON ->PRESETCTRL |= (0<<5);
			LPC_SYSCON ->PRESETCTRL |= (1<<5);
			LPC_SWM ->PINASSIGN2 = (tx<<16) | (rx << 24);
			LPC_USART2->BRG  = ((max_baud/baud) -1);
			LPC_USART2->CFG |= (1<<2); // 8 bit
			LPC_USART2->CFG |= (1<<0);// uart on
		break;
	}
}


void send_char(int port, char tx_data)
{
	switch(port)
	{
		case 0:
			while(~LPC_USART0->STAT & (0x1 << 2)); // tx ready ?????
			LPC_USART0->TXDAT = tx_data;
		break;
		
		case 1:
			while(~LPC_USART1->STAT & (0x1 << 2)); // tx ready ?????
			LPC_USART1->TXDAT = tx_data;
		break;
		
		case 2:
			while(~LPC_USART2->STAT & (0x1 << 2)); // tx ready ?????
			LPC_USART2->TXDAT = tx_data;
		break;
	}
}

void send_string(int port, char* tx_data)
{
	switch(port)
	{
		case 0:
			while(*tx_data != '\0'){
			while(~LPC_USART0->STAT & (0x1 << 2)); // tx ready ?????
			LPC_USART0->TXDAT = *tx_data++;
			}
		break;
		
		case 1:
			while(*tx_data != '\0'){
			while(~LPC_USART1->STAT & (0x1 << 2)); // tx ready ?????
			LPC_USART1->TXDAT = *tx_data++;
			}
		break;
		
		case 2:
			while(*tx_data != '\0'){
			while(~LPC_USART2->STAT & (0x1 << 2)); // tx ready ?????
			LPC_USART2->TXDAT = *tx_data++;
			}
		break;
	}
}


int rx_char(int port)
{
 int rx_data=0;
	switch(port)
	{
		case 0:
			while(~LPC_USART0->STAT & (0x1 << 0)); // rx ready ?????
			rx_data = LPC_USART0->RXDAT;
	//	return rx_data;
		break;
		
		case 1:
			while(~LPC_USART1->STAT & (0x1 << 0)); // rx ready ?????
			rx_data = LPC_USART1->RXDAT;
			
		break;
		
		case 2:
			while(~LPC_USART2->STAT & (0x1 << 0)); // rx ready ?????
			rx_data = LPC_USART2->RXDAT;
	
		break;
	}
return rx_data;
}

void send_dec(int port, int data)
{
	switch(port)
	{
		case 0:
			while(~LPC_USART0->STAT & (0x1 << 2)); // tx ready ?????
			LPC_USART0->TXDAT = data;
		
		break;
		
		case 1:
			while(~LPC_USART1->STAT & (0x1 << 2)); // tx ready ?????
			LPC_USART1->TXDAT = data;
		break;
		
		case 2:
			while(~LPC_USART2->STAT & (0x1 << 2)); // tx ready ?????
			LPC_USART2->TXDAT = data;
}
}


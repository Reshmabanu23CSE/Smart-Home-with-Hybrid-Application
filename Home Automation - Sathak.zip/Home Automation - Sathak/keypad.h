
extern unsigned char key;
extern char key_p[4]; 
//extern int o;

void i2c_init(void);
void i2C_tx_rx(void);
void i2c_write(char slave_add, char data, char data2);
int i2c_read(char slave_add);
char keypad_no(void);
void key_pressed(void);
void rand_gen(void);
	void cmp(void);
char keypad_alp(void);


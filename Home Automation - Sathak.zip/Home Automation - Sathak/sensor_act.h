
void inside_home(void);
	void out(void);

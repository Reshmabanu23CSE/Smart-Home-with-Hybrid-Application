#include "LPC8xx.h"                     // Device header
#include "uart.h"

int rx_data, rx_data1;



void i2c_init()
{	
	LPC_SYSCON->SYSAHBCLKCTRL |= (1<<5)|(1<<7)|(1<<18);  //CLOCK FOR SWM & IO CON
	
	LPC_SYSCON->PRESETCTRL |= (0<<6);  				//RESET
	LPC_SYSCON->PRESETCTRL |= (1<<6);					//CLEAR & MAKE I2C READY FOR OPERATION
	
	LPC_SWM->PINASSIGN7 = 11<<24;					//SDA P0_11
	LPC_SWM->PINASSIGN8 = 10<<0;					//SCL P0_10
	
//	LPC_IOCON->PIO0_10 |= (1<<9);							//FAST PLUS MODE
//	LPC_IOCON->PIO0_11 |= (1<<9);							//FAST PLUS MODE
	
}

void i2C_tx_rx()
{

 	LPC_I2C0->CLKDIV =2;
//	LPC_I2C0->MSTTIME |= (0X04<<0) | (0X03<<4);
	LPC_I2C0->CFG |= (1<<0);										//ENABLE MASTER
}

void i2c_write(char slave_add, char data, char data2)
{
	//LPC_I2C0 ->MSTDAT |=0x00;
	LPC_I2C0 ->MSTDAT = slave_add ;				// Write slave address to MSTDAT
	delay(10);
	LPC_I2C0 ->MSTCTL = (1<<1);						//Start the transmission by setting the MSTSTART bit to 1 in the Master control register.
	while(!(LPC_I2C0 ->STAT & (0x1<<0)) );		// Wait for the pending status to be set
	
	LPC_I2C0 ->MSTDAT = data; 						// Write 8 bits of data to the MSTDAT register
	delay(10);
	LPC_I2C0 ->MSTCTL =(1<<0);						// Continue with the transmission
	while(!(LPC_I2C0 ->STAT & (0x1<<0) ));		// Wait for the pending status to be set
	
	LPC_I2C0 ->MSTDAT = data2; 						// Write 8 bits of data to the MSTDAT register
	delay(10);
	LPC_I2C0 ->MSTCTL =(1<<0);						// Continue with the transmission
	while(!(LPC_I2C0 ->STAT & (0x1<<0) ));		// Wait for the pending status to be set
	
	LPC_I2C0 ->MSTCTL = (1<2);						//Stop the transmission
	delay(20);
}

int i2c_read(char slave_add)
{
//	//	LPC_I2C0 ->MSTDAT |=0xFF;
	LPC_I2C0 ->MSTDAT = slave_add ;				// Write slave address to MSTDAT
	LPC_I2C0 ->MSTCTL = 0x2;	//(1<<1);						//Start the transmission by setting the MSTSTART bit to 1 in the Master control register.
	while(!(LPC_I2C0 ->STAT & 	0x1));	//(1<<0)) );		// Wait for the pending status to be set
////	
	rx_data = LPC_I2C0 ->MSTDAT;
		LPC_I2C0 ->MSTCTL =	0x1;	//(1<<0);						// Continue with the transmission
	while(!(LPC_I2C0 ->STAT & 	0x1));	//(1<<0)) );		// Wait for the pending status to be set
//	
	//rx_data1 = LPC_I2C0 ->MSTDAT;
	LPC_I2C0 ->MSTCTL =		0x1;	//(1<<0);						// Continue with the transmission
	while(!(LPC_I2C0 ->STAT & 0x1));//(1<<0)) );		// Wait for the pending status to be set

	LPC_I2C0 ->MSTCTL = 0x4; //(1<<2);						//Stop the transmission

	return rx_data;
}
